import 'package:flutter/foundation.dart';

import '../models/admin_client.dart';
import '../models/managed_service.dart';

/// Fuente de datos temporal. Reemplazala por una API o base de datos cuando
/// el proyecto necesite persistir los cambios entre sesiones.
class AdminDataService extends ChangeNotifier {
  final List<AdminClient> _clients = [
    const AdminClient(id: 'carlos', name: 'Carlos Martinez', email: 'carlos@correo.com', phone: '+57 300 555 1020'),
    const AdminClient(id: 'andrea', name: 'Andrea Gomez', email: 'andrea@correo.com', phone: '+57 310 628 2041'),
    const AdminClient(id: 'santiago', name: 'Santiago Ruiz', email: 'santiago@correo.com', phone: '+57 315 804 1182'),
  ];

  final List<ManagedService> _services = [
    const ManagedService(id: 'preventivo', name: 'Mantenimiento Preventivo', description: 'Aceite, filtros y revision general.', price: r'$120,000 COP', active: true),
    const ManagedService(id: 'mecanica', name: 'Mecanica General', description: 'Frenos, suspension y reparaciones.', price: r'$250,000 COP', active: true),
    const ManagedService(id: 'diagnostico', name: 'Diagnostico Electronico', description: 'Lectura de codigos y fallas.', price: r'$80,000 COP', active: false),
  ];

  List<AdminClient> get clients => List.unmodifiable(_clients);
  List<ManagedService> get services => List.unmodifiable(_services);
  List<ManagedService> get activeServices => List.unmodifiable(_services.where((service) => service.active));

  void saveClient(AdminClient client) {
    final index = _clients.indexWhere((item) => item.id == client.id);
    if (index == -1) {
      _clients.add(client);
    } else {
      _clients[index] = client;
    }
    notifyListeners();
  }

  void deleteClient(String id) {
    _clients.removeWhere((client) => client.id == id);
    notifyListeners();
  }

  void saveService(ManagedService service) {
    final index = _services.indexWhere((item) => item.id == service.id);
    if (index == -1) {
      _services.add(service);
    } else {
      _services[index] = service;
    }
    notifyListeners();
  }

  void deleteService(String id) {
    _services.removeWhere((service) => service.id == id);
    notifyListeners();
  }
}
