# Driven Yield Citas

Aplicacion movil Flutter para un taller automotriz. Incluye la experiencia de cliente (servicios y citas) y un acceso independiente de administrador con ventas, clientes y catalogo de servicios.

## Arquitectura

El proyecto se reorganizo por responsabilidades, siguiendo la estructura solicitada:

```text
lib/
|-- main.dart                         # Punto de entrada
|-- app.dart                          # Navegacion y composicion de la app
|
|-- core/
|   |-- constants/
|   |   `-- app_colors.dart           # Colores compartidos
|   `-- theme/
|       `-- app_theme.dart            # Tema global de Flutter
|
|-- models/
|   |-- admin_client.dart             # Datos de clientes
|   |-- managed_service.dart          # Datos de servicios
|   |-- booking_service.dart          # Modelo reutilizable para reservas
|   `-- app_section.dart              # Estados de navegacion
|
|-- services/
|   `-- admin_data_service.dart       # CRUD temporal de clientes y servicios
|
|-- screens/
|   |-- welcome/
|   |   `-- welcome_screen.dart
|   |-- auth/
|   |   `-- auth_screens.dart
|   |-- client/
|   |   `-- client_screens.dart
|   `-- admin/
|       `-- admin_screens.dart
|
`-- widgets/
    |-- layout.dart                   # Botones, campos, estados vacios
    `-- navigation_bars.dart          # Navegacion de cliente y administrador
```

`AdminDataService` concentra las operaciones de crear, editar, activar/desactivar y eliminar. Las pantallas solo renderizan los datos y solicitan acciones a ese servicio. Por ahora los cambios viven mientras la app esta abierta; para persistirlos, el siguiente paso seria conectar este servicio a Firebase o a una API propia.

## Funcionalidad incluida

- Inicio de sesion de cliente y acceso diferenciado de administrador.
- Panel administrativo con ventas, metricas y citas.
- Clientes: crear, editar y eliminar.
- Servicios: crear, editar, activar/desactivar y eliminar.
- Los servicios activos del administrador se muestran para el cliente.

## Ejecutar como una app de celular en Visual Studio Code

1. Abre esta carpeta en Visual Studio Code e instala las extensiones **Flutter** y **Dart**.
2. En la terminal integrada ejecuta, una sola vez:

   ```bash
   flutter create .
   flutter pub get
   ```

3. Presiona `Ctrl+Shift+P`, ejecuta **Flutter: Launch Emulator** y elige un emulador Android tipo Pixel. Si no tienes uno, crealo primero desde **Android Studio > Device Manager**.
4. Con el emulador encendido, presiona `F5`. La aplicacion se abrira con las dimensiones de un telefono.

Tambien puedes conectar un telefono Android por USB con la depuracion USB activada, seleccionarlo en VS Code y presionar `F5`.

Para abrir el panel administrativo: entra a **Iniciar sesion** y pulsa **Acceder como administrador**. Es una demostracion y no valida credenciales todavia.
