import 'package:flutter/material.dart';

import '../../core/constants/app_colors.dart';
import '../../models/app_section.dart';
import '../../widgets/layout.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key, required this.navigate});

  final ValueChanged<AppSection> navigate;

  @override
  Widget build(BuildContext context) => AppPage(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(32, 42, 32, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              const Text('TALLER AUTOMOTRIZ', style: TextStyle(color: AppColors.accent, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 3)),
              const SizedBox(height: 18),
              const Text('MAXIMO\nRENDI\nMIENTO', style: TextStyle(color: Color(0xFFEFEFEF), fontSize: 50, fontWeight: FontWeight.w900, height: .9, letterSpacing: -1.5)),
              const SizedBox(height: 42),
              Row(
                children: [
                  OutlinedButton(
                    onPressed: () => navigate(AppSection.login),
                    style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white), padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 12)),
                    child: const Text('SOLICITAR SERVICIO', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                  ),
                  const SizedBox(width: 8),
                  TextButton(
                    onPressed: () => navigate(AppSection.services),
                    child: const Text('CONOCER MAS', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                  ),
                ],
              ),
              const SizedBox(height: 44),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: AppColors.panel, borderRadius: BorderRadius.circular(17)),
                child: const Row(
                  children: [
                    Icon(Icons.speed_outlined, color: AppColors.accent, size: 42),
                    SizedBox(width: 16),
                    Expanded(child: Text('Ofrecemos el mejor servicio para tu automovil, con calidad garantizada y una experiencia recomendada.', style: TextStyle(color: Color(0xFFAAAAAA), fontSize: 12, height: 1.45))),
                  ],
                ),
              ),
              const Spacer(),
              const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [_Indicator(active: true), _Indicator(), _Indicator()],
              ),
            ],
          ),
        ),
      );
}

class _Indicator extends StatelessWidget {
  const _Indicator({this.active = false});

  final bool active;

  @override
  Widget build(BuildContext context) => Container(
        width: active ? 25 : 8,
        height: 4,
        margin: const EdgeInsets.symmetric(horizontal: 3),
        decoration: BoxDecoration(color: active ? AppColors.accent : Colors.white24, borderRadius: BorderRadius.circular(10)),
      );
}
